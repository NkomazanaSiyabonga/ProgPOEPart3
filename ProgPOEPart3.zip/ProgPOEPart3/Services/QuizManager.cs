﻿using System.Collections.Generic;

namespace CyberSecurityChatBot.Services
{
    public class QuizQuestion
    {
        public string Question { get; set; }
        public List<string> Options { get; set; }
        public int CorrectAnswerIndex { get; set; }
        public string Explanation { get; set; }
    }

    public class QuizManager
    {
        private List<QuizQuestion> questions;
        private int currentIndex;
        private int score;

        public int CurrentIndex => currentIndex;
        public int CurrentScore => score;
        public int QuestionCount => questions.Count;
        public bool IsQuizComplete => currentIndex >= questions.Count;

        public QuizManager()
        {
            LoadQuestions();
            ResetQuiz();
        }

        private void LoadQuestions()
        {
            questions = new List<QuizQuestion>
    {
        new QuizQuestion
        {
            Question = "What is phishing?",
            Options = new List<string> { "A type of fish", "An email scam", "A firewall", "A secure protocol" },
            CorrectAnswerIndex = 1,
            Explanation = "Phishing is a type of online scam where attackers impersonate legitimate institutions."
        },
        new QuizQuestion
        {
            Question = "Which of the following is a strong password?",
            Options = new List<string> { "123456", "password", "Welcome1", "J@ne2024!#" },
            CorrectAnswerIndex = 3,
            Explanation = "Strong passwords use a mix of uppercase, lowercase, symbols, and numbers."
        },
        new QuizQuestion
        {
            Question = "What should you do if you receive a suspicious email?",
            Options = new List<string> { "Click the link", "Report it", "Ignore it", "Forward it to friends" },
            CorrectAnswerIndex = 1,
            Explanation = "You should report suspicious emails to your IT department or service provider."
        },
        new QuizQuestion
        {
            Question = "Which device is safest for storing sensitive data?",
            Options = new List<string> { "Public WiFi", "Unencrypted USB", "Encrypted external drive", "Printed paper" },
            CorrectAnswerIndex = 2,
            Explanation = "Encrypted external drives protect your data even if the device is lost."
        },
        new QuizQuestion
        {
            Question = "Two-factor authentication (2FA) provides:",
            Options = new List<string> { "Double internet speed", "Extra backup", "Additional security", "Free WiFi access" },
            CorrectAnswerIndex = 2,
            Explanation = "2FA provides additional security by requiring a second form of verification."
        },
        new QuizQuestion
        {
            Question = "Which of the following is a common sign of a phishing website?",
            Options = new List<string> { "HTTPS in the URL", "Well-designed layout", "Misspelled domain name", "Locked padlock icon" },
            CorrectAnswerIndex = 2,
            Explanation = "Phishing websites often use misspelled or lookalike domain names to trick users."
        },
        new QuizQuestion
        {
            Question = "What does a firewall do?",
            Options = new List<string> { "Cooks data", "Blocks unauthorized access", "Creates viruses", "Boosts Wi-Fi speed" },
            CorrectAnswerIndex = 1,
            Explanation = "A firewall helps protect your network by filtering incoming and outgoing traffic."
        },
            new QuizQuestion
        {
            Question = "Phishing is a type of email scam.",
            Options = new List<string> { "True", "False" },
            CorrectAnswerIndex = 0,
            Explanation = "Phishing is a type of online scam where attackers impersonate legitimate institutions."
        },
        // True/False example 2
        new QuizQuestion
        {
            Question = "Two-factor authentication provides additional security.",
            Options = new List<string> { "True", "False" },
            CorrectAnswerIndex = 0,
            Explanation = "2FA requires a second form of verification for extra protection."
        },
        // True/False example 3
        new QuizQuestion
        {
            Question = "Ransomware is a tool used to protect files.",
            Options = new List<string> { "True", "False" },
            CorrectAnswerIndex = 1,
            Explanation = "Ransomware is malware that locks your files and demands payment."
        }
    };
        }

       

        public void ResetQuiz()
        {
            currentIndex = 0;
            score = 0;
        }

        public QuizQuestion GetCurrentQuestion()
        {
            if (currentIndex < questions.Count)
                return questions[currentIndex];
            return null;
        }

        public bool CheckAnswer(int selectedIndex)
        {
            var currentQuestion = questions[currentIndex];
            bool isCorrect = selectedIndex == currentQuestion.CorrectAnswerIndex;
            if (isCorrect)
                score++;
            return isCorrect;
        }

        public void MoveToNextQuestion()
        {
            currentIndex++;
        }

        public string GetFinalFeedback()
        {
            if (score == QuestionCount)
                return "🎉 Excellent! You got all the answers correct.";
            else if (score >= QuestionCount * 0.6)
                return "👍 Good job! Review some areas to strengthen your knowledge.";
            else
                return "🔁 Keep practicing! Cybersecurity awareness is important.";
        }
    }
}
