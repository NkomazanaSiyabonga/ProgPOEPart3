﻿using System;
using System.Linq;
using Microsoft.VisualBasic;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;
using CyberSecurityChatBot.Models;
using CyberSecurityChatBot.Services;

namespace CyberSecurityChatBot
{
    public partial class MainWindow : Window
    {
        private QuizManager quizManager = new QuizManager();
        private ObservableCollection<CyberSecurityTask> tasks = new ObservableCollection<CyberSecurityTask>();

        public MainWindow()
        {
            InitializeComponent();
            TasksListBox.ItemsSource = tasks;
            ResetQuizUI();
        }

        // CHATBOT SIMULATION
        private void btnSendMessage_Click(object sender, RoutedEventArgs e)
        {
            string userMessage = txtUserMessage.Text.Trim();
            if (string.IsNullOrWhiteSpace(userMessage)) return;

            txtChatLog.AppendText($"You: {userMessage}\n");

            string response = ProcessChatMessage(userMessage);
            txtChatLog.AppendText($"Bot: {response}\n\n");

            txtChatLog.ScrollToEnd();
            LogActivity($"User message: \"{userMessage}\"");
            txtUserMessage.Clear();
        }


        private string ProcessBotLogic(string message)
        {
            message = message.ToLower();

            // Handle adding a task
            if (message.Contains("add") && (message.Contains("task") || message.Contains("reminder")))
            {
                string title = ExtractTaskTitle(message);
                string description = "Reminder from chatbot";

                tasks.Add(new CyberSecurityTask
                {
                    Title = string.IsNullOrWhiteSpace(title) ? "Untitled Task" : title,
                    Description = description,
                    DueDate = null,
                    IsCompleted = false
                });

                LogActivity($"Task added via chatbot: \"{title}\"");
                return $"I’ve added a task for you: \"{title}\".";
            }

            // Handle quiz intent
            if (message.Contains("start quiz") || message.Contains("take quiz") || message.Contains("quiz"))
            {
                MainTabControl.SelectedIndex = 2; // Switch to quiz tab
                StartQuiz_Click(null, null);
                return "Starting the quiz for you.";
            }

            // Cybersecurity topics
            if (message.Contains("phishing"))
                return "Phishing is a type of cyber attack where attackers try to trick you into giving personal information by pretending to be a trustworthy source, like a bank or government agency. Never click suspicious links or give out credentials.";

            if (message.Contains("password safety") || message.Contains("password tips"))
                return "Use strong, unique passwords for each account. Include letters, numbers, and symbols, and consider using a password manager to keep track of them.";

            if (message.Contains("cybersecurity tips") || message.Contains("general tips"))
                return "Some general cybersecurity tips: 1) Keep your software updated, 2) Use antivirus protection, 3) Avoid suspicious emails or links, 4) Use strong passwords, 5) Enable two-factor authentication.";

            // Generic greeting
            if (message.Contains("hello") || message.Contains("hi"))
                return "Hello! I'm here to help you with cybersecurity, reminders, and quizzes.";

            // Fallback
            return "I'm not sure how to help with that, but you can ask me to add tasks, start the quiz, or ask cybersecurity questions like 'What is phishing?'";
        }


        private string ProcessChatMessage(string input)
        {
            input = input.ToLower();

            // Activity Summary
            if (input.Contains("remind") || input.Contains("add task") || input.Contains("reminder") || input.Contains("remember"))
            {
                // Ask for task title first
                string title = ExtractTaskTitle(input);
                if (string.IsNullOrWhiteSpace(title) || title == "Unnamed Task")
                {
                    title = Microsoft.VisualBasic.Interaction.InputBox("What should I name the task/reminder?", "Enter Task Title");
                    if (string.IsNullOrWhiteSpace(title))
                        return "No task title was provided. I couldn't create the task.";
                }

                // Ask for due date
                string dueDateStr = PromptForDueDate(title);
                if (DateTime.TryParse(dueDateStr, out DateTime dueDate))
                {
                    var newTask = new CyberSecurityTask
                    {
                        Title = title,
                        Description = "Added via chatbot",
                        DueDate = dueDate,
                        IsCompleted = false
                    };
                    tasks.Add(newTask);
                    LogActivity($"Added via chatbot: \"{title}\" (Due: {dueDate:dd MMM})");
                    return $"Task \"{title}\" added with due date: {dueDate:dd MMM yyyy}";
                }

                return "Could not add the task. Invalid date provided.";
            }


            // Fallback: call general bot logic
            return ProcessBotLogic(input);
        }



        // Extract title after "remind me to..." or "add a task to..."
        private string ExtractTaskTitle(string input)
        {
            string[] keywords = { "remind me to", "add a task to", "remember to", "task to" };
            foreach (var keyword in keywords)
            {
                if (input.Contains(keyword))
                {
                    return System.Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(
                        input.Substring(input.IndexOf(keyword) + keyword.Length).Trim());
                }
            }
            return "Unnamed Task";
        }

        private string PromptForDueDate(string taskTitle)
        {
            // Consider using a Message Box or another method to get input
            return Microsoft.VisualBasic.Interaction.InputBox($"What date should I remind you to '{taskTitle}'? (e.g., 2025-07-01)", "Set Reminder Due Date");
        }




        // === TASK ASSISTANT METHODS ===
        private void AddTask_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TaskTitleInput.Text)) return;

            var task = new CyberSecurityTask
            {
                Title = TaskTitleInput.Text,
                Description = TaskDescriptionInput.Text,
                DueDate = TaskDueDatePicker.SelectedDate,
                IsCompleted = false
            };

            tasks.Add(task);

            LogActivity($"Task added: \"{task.Title}\"");

            TaskTitleInput.Clear();
            TaskDescriptionInput.Clear();
            TaskDueDatePicker.SelectedDate = null;
        }


        private void CompleteTask_Click(object sender, RoutedEventArgs e)
        {
            if (sender is FrameworkElement element && element.Tag is CyberSecurityTask task)
            {
                task.IsCompleted = true;
                task.CompletedDate = DateTime.Now;
                MessageBox.Show($"Marked '{task.Title}' as complete.");

                LogActivity($"Task marked complete: \"{task.Title}\"");
            }
        }


        private void RemoveTask_Click(object sender, RoutedEventArgs e)
        {
            if (sender is FrameworkElement element && element.Tag is CyberSecurityTask task)
            {
                tasks.Remove(task);
                LogActivity($"Task removed: \"{task.Title}\"");
            }
        }


        // === QUIZ METHODS ===
        private void ResetQuizUI()
        {
            QuizQuestionText.Text = "Press 'Start Quiz' to begin.";
            QuizOption1.Content = QuizOption2.Content = QuizOption3.Content = QuizOption4.Content = "";
            QuizExplanationText.Text = "";
            QuizScoreText.Text = "";
            QuizScoreText.Visibility = Visibility.Collapsed;
            QuizProgressText.Text = "";
            SubmitAnswerButton.IsEnabled = false;
            NextQuestionButton.IsEnabled = false;
        }

        private void StartQuiz_Click(object sender, RoutedEventArgs e)
        {
            quizManager.ResetQuiz();
            ShowCurrentQuestion();
            SubmitAnswerButton.IsEnabled = true;
            NextQuestionButton.IsEnabled = false;
            QuizScoreText.Text = "";

            LogActivity("Quiz started");
        }

        private void SubmitAnswer_Click(object sender, RoutedEventArgs e)
        {
            int selected = -1;
            if (QuizOption1.IsChecked == true) selected = 0;
            else if (QuizOption2.IsChecked == true) selected = 1;
            else if (QuizOption3.IsChecked == true) selected = 2;
            else if (QuizOption4.IsChecked == true) selected = 3;

            if (selected == -1)
            {
                MessageBox.Show("Please select an option.");
                return;
            }

            var question = quizManager.GetCurrentQuestion();
            bool isCorrect = quizManager.CheckAnswer(selected);
            QuizExplanationText.Text = question.Explanation + (isCorrect ? "\n✅ Correct!" : "\n❌ Incorrect.");
            SubmitAnswerButton.IsEnabled = false;
            NextQuestionButton.IsEnabled = true;

            LogActivity($"Submitted answer to: \"{question.Question}\" - {(isCorrect ? "Correct" : "Incorrect")}");
        }

        private void NextQuestion_Click(object sender, RoutedEventArgs e)
        {
            quizManager.MoveToNextQuestion();

            if (quizManager.IsQuizComplete)
            {
                QuizQuestionText.Text = "Quiz Complete!";
                QuizScoreText.Text = $"Score: {quizManager.CurrentScore}/{quizManager.QuestionCount}";
                QuizExplanationText.Text = quizManager.GetFinalFeedback();
                SubmitAnswerButton.IsEnabled = false;
                NextQuestionButton.IsEnabled = false;

                LogActivity($"Quiz complete. Final Score: {quizManager.CurrentScore}/{quizManager.QuestionCount}");
            }
            else
            {
                ShowCurrentQuestion();
                SubmitAnswerButton.IsEnabled = true;
                NextQuestionButton.IsEnabled = false;
            }
        }


        private void ShowCurrentQuestion()
        {
            var question = quizManager.GetCurrentQuestion();
            if (question == null) return;

            QuizQuestionText.Text = question.Question;
            QuizOption1.IsChecked = QuizOption2.IsChecked = QuizOption3.IsChecked = QuizOption4.IsChecked = false;

            QuizOption1.Content = question.Options[0];
            QuizOption2.Content = question.Options[1];
            QuizOption3.Content = question.Options[2];
            QuizOption4.Content = question.Options[3];

            QuizExplanationText.Text = "";
            QuizProgressText.Text = $"Question {quizManager.CurrentIndex + 1} of {quizManager.QuestionCount}";
            QuizScoreText.Visibility = Visibility.Collapsed;
        }



        // === ACTIVITY LOG METHODS ===
        private List<string> allActivityLogs = new List<string>();
        private int logsToShow = 10;
        private bool showingAllLogs = false;

        private void LogActivity(string message)
        {
            string timestampedMessage = $"[{DateTime.Now:HH:mm:ss}] {message}";
            allActivityLogs.Add(timestampedMessage);
            RefreshActivityLogDisplay();
        }

        private void RefreshActivityLogDisplay()
        {
            ActivityLogListBox.Items.Clear();
            var logs = showingAllLogs ? allActivityLogs : allActivityLogs.Skip(Math.Max(0, allActivityLogs.Count - logsToShow));
            foreach (var log in logs)
            {
                ActivityLogListBox.Items.Add(log);
            }

            ShowMoreLogButton.Visibility = allActivityLogs.Count > logsToShow && !showingAllLogs ? Visibility.Visible : Visibility.Collapsed;

            if (ActivityLogListBox.Items.Count > 0)
                ActivityLogListBox.ScrollIntoView(ActivityLogListBox.Items[ActivityLogListBox.Items.Count - 1]);
        }

        private void ShowMoreLogButton_Click(object sender, RoutedEventArgs e)
        {
            showingAllLogs = true;
            RefreshActivityLogDisplay();
        }

        private void ClearLog_Click(object sender, RoutedEventArgs e)
        {
            allActivityLogs.Clear();
            RefreshActivityLogDisplay();
        }

        private void RefreshLog_Click(object sender, RoutedEventArgs e)
        {
            LogActivity("Activity log refreshed");
        }



    }
}
