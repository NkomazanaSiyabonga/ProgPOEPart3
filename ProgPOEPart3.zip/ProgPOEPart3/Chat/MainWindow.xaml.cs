﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CyberSecurityChatBot.Models;
using CyberSecurityChatBot.Services;


namespace CyberSecurityChatBot

{

    public partial class MainWindow : Window
    {
        private readonly QuizManager _quizManager = new QuizManager();
        private bool _showingExplanation = false;

        private List<CybersecurityTask> _taskList = new List<CybersecurityTask>();
        public MainWindow()
        {
            InitializeComponent();
            ActivityLogger.LogActivity("Application started");
            RefreshActivityLog();
        }

        #region Task Assistant Methods
        private List<CybersecurityTask> _tasks = new List<CybersecurityTask>();

        private void AddTask_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TaskTitleInput.Text))
            {
                MessageBox.Show("Please enter a task title");
                return;
            }

            var newTask = new CybersecurityTask
            {
                Title = TaskTitleInput.Text,
                Description = TaskDescriptionInput.Text,
                DueDate = TaskDueDatePicker.SelectedDate
            };

            _tasks.Add(newTask);
            TasksListBox.ItemsSource = null; // Refresh binding
            TasksListBox.ItemsSource = _tasks;

            ActivityLogger.LogActivity("Task added", newTask.Title);

            TaskTitleInput.Clear();
            TaskDescriptionInput.Clear();
            TaskDueDatePicker.SelectedDate = null;
        }

        private void RefreshTaskList()
        {
            TasksListBox.ItemsSource = null;
            TasksListBox.ItemsSource = _tasks
                .OrderBy(t => t.IsCompleted)
                .ThenBy(t => t.DueDate ?? DateTime.MaxValue)
                .ToList();
        }



        private void CompleteTask_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is CybersecurityTask task)
            {
                task.IsCompleted = true;
                task.CompletedDate = DateTime.Now;
                RefreshTaskList();
                ActivityLogger.LogActivity("Task completed", task.Title);
            }
        }

        private void RemoveTask_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is CybersecurityTask task)
            {
                _tasks.Remove(task);
                RefreshTaskList();
                ActivityLogger.LogActivity("Task removed", task.Title);
            }
        }


        #endregion

        #region Quiz Methods
        private void StartQuiz_Click(object sender, RoutedEventArgs e)
        {
            _quizManager.ResetQuiz();
            LoadQuestion();
            SetQuizButtonsState(startQuiz: false, submitAnswer: true, nextQuestion: false);
            ActivityLogger.LogActivity("Quiz started");
            RefreshActivityLog();
        }

        private void LoadQuestion()
        {
            if (_quizManager.IsQuizComplete)
            {
                DisplayQuizCompletion();
                return;
            }

            var question = _quizManager.GetCurrentQuestion();
            QuizQuestionText.Text = question.Question;
            QuizOption1.Content = question.Options[0];
            QuizOption2.Content = question.Options[1];
            QuizOption3.Content = question.Options[2];
            QuizOption4.Content = question.Options[3];

            ResetQuizOptions();
        }

        private void SubmitAnswer_Click(object sender, RoutedEventArgs e)
        {
            int selectedIndex = GetSelectedAnswerIndex();
            if (selectedIndex == -1)
            {
                MessageBox.Show("Please select an answer");
                return;
            }

            bool isCorrect = _quizManager.CheckAnswer(selectedIndex);
            var currentQuestion = _quizManager.GetCurrentQuestion();

            QuizExplanationText.Text = currentQuestion.Explanation;
            _showingExplanation = true;
            SetQuizButtonsState(submitAnswer: false, nextQuestion: true);

            ActivityLogger.LogActivity("Quiz answer submitted", isCorrect ? "Correct" : "Incorrect");
            RefreshActivityLog();
        }

        private void NextQuestion_Click(object sender, RoutedEventArgs e)
        {
            _quizManager.MoveToNextQuestion();
            LoadQuestion();
            SetQuizButtonsState(submitAnswer: true, nextQuestion: false);
        }

        private void SetQuizButtonsState(bool startQuiz = true, bool submitAnswer = false, bool nextQuestion = false)
        {
            StartQuizButton.IsEnabled = startQuiz;
            SubmitAnswerButton.IsEnabled = submitAnswer;
            NextQuestionButton.IsEnabled = nextQuestion;
        }

        private void DisplayQuizCompletion()
        {
            QuizQuestionText.Text = "Quiz Complete!";
            ClearQuizOptions();
            QuizScoreText.Text = $"Final Score: {_quizManager.CurrentScore}/{_quizManager.QuestionCount}";
            QuizExplanationText.Text = _quizManager.GetFinalFeedback();
            SetQuizButtonsState(startQuiz: true, submitAnswer: false, nextQuestion: false);
        }

        private void ClearQuizOptions()
        {
            QuizOption1.Content = QuizOption2.Content = QuizOption3.Content = QuizOption4.Content = "";
        }

        private void ResetQuizOptions()
        {
            QuizOption1.IsChecked = QuizOption2.IsChecked = QuizOption3.IsChecked = QuizOption4.IsChecked = false;
            QuizScoreText.Text = $"Score: {_quizManager.CurrentScore}/{_quizManager.QuestionCount}";
            QuizExplanationText.Text = "";
            _showingExplanation = false;
        }

        private int GetSelectedAnswerIndex()
        {
            if (QuizOption1.IsChecked == true) return 0;
            if (QuizOption2.IsChecked == true) return 1;
            if (QuizOption3.IsChecked == true) return 2;
            if (QuizOption4.IsChecked == true) return 3;
            return -1;
        }
        #endregion

        #region Activity Log Methods
        private void RefreshActivityLog()
        {
            ActivityLogListBox.ItemsSource = ActivityLogger.GetRecentActivities(50);
            if (ActivityLogListBox.Items.Count > 0)
                ActivityLogListBox.ScrollIntoView(ActivityLogListBox.Items[ActivityLogListBox.Items.Count - 1]);
        }

        private void RefreshLog_Click(object sender, RoutedEventArgs e)
        {
            RefreshActivityLog();
            ActivityLogger.LogActivity("Log refreshed");
        }

        private void ClearLog_Click(object sender, RoutedEventArgs e)
        {
            ActivityLogger.ClearLog();
            RefreshActivityLog();
            ActivityLogger.LogActivity("Log cleared");
        }
        #endregion
    }
}
