﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CyberSecurityChatBot.Models;


namespace CyberSecurityChatBot.Services
{
    public class BotService
    {
        private readonly TaskManager _taskManager;
        private readonly QuizManager _quizManager;

        public BotService(TaskManager taskManager, QuizManager quizManager)
        {
            _taskManager = taskManager;
            _quizManager = quizManager;
        }

        public string ProcessInput(string input)
        {
            if (input.Contains("task"))
                return "Go to the Task tab to add or manage tasks.";

            if (input.Contains("quiz"))
                return "Switch to the Quiz tab to begin your cybersecurity quiz.";

            if (input.Contains("hello") || input.Contains("hi"))
                return "Hi! I'm your Cybersecurity Assistant. How can I help?";

            return "I'm here to help you stay safe online. Ask me about cybersecurity, tasks, or quizzes.";
        }
    }
}

