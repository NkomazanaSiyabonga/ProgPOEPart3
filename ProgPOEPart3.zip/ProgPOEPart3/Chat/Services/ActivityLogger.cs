﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CyberSecurityChatBot.Models;


namespace CyberSecurityChatBot.Services
{
    public static class ActivityLogger
    {
        private static readonly List<ActivityLogEntry> _activities = new List<ActivityLogEntry>();
        private static readonly int _maxLogSize = 50;

        public static void LogActivity(string action, string details = "")
        {
            _activities.Add(new ActivityLogEntry { Action = action, Details = details });
            if (_activities.Count > _maxLogSize)
                _activities.RemoveAt(0);
        }

        public static List<string> GetRecentActivities(int count = 10)
        {
            return _activities
                .Skip(Math.Max(0, _activities.Count - count))
                .Select(a => a.ToString())
                .ToList();
        }


        public static void ClearLog() => _activities.Clear();
    }
}

