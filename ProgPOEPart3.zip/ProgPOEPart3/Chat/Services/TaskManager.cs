﻿using System;
using CyberSecurityChatBot.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;




namespace CyberSecurityChatBot.Services
{
    public class TaskManager
    {
        private readonly List<CybersecurityTask> _tasks = new List<CybersecurityTask>();

        public void AddTask(string title, string description, DateTime? dueDate)
        {
            _tasks.Add(new CybersecurityTask
            {
                Title = title,
                Description = description,
                DueDate = dueDate
            });
        }

        public List<CybersecurityTask> GetTasks() =>
            _tasks.OrderBy(t => t.DueDate ?? DateTime.MaxValue).ToList();

        public void MarkTaskComplete(int index)
        {
            if (index >= 0 && index < _tasks.Count)
            {
                _tasks[index].IsCompleted = true;
                _tasks[index].CompletedDate = DateTime.Now;
            }
        }

        public void RemoveTask(int index)
        {
            if (index >= 0 && index < _tasks.Count)
                _tasks.RemoveAt(index);
        }
    }
}

