﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CyberSecurityChatBot.Models;


namespace CyberSecurityChatBot.Services
{
    public class QuizManager
    {
        private readonly List<QuizQuestion> _questions = new List<QuizQuestion>
        {
            new QuizQuestion
            {
                Question = "What should you do if you receive an email asking for your password?",
                Options = new List<string>
                {
                    "Reply with your password",
                    "Delete the email",
                    "Report the email as phishing",
                    "Ignore it"
                },
                CorrectAnswerIndex = 2,
                Explanation = "You should report phishing emails to help prevent others from falling victim to the scam."
            }
        };

        private int _currentQuestionIndex = 0;
        private int _currentScore = 0;

        public int QuestionCount => _questions.Count;
        public int CurrentScore => _currentScore;
        public bool IsQuizComplete => _currentQuestionIndex >= _questions.Count;

        public QuizQuestion GetCurrentQuestion() => _questions[_currentQuestionIndex];

        public bool CheckAnswer(int selectedIndex)
        {
            bool isCorrect = selectedIndex == _questions[_currentQuestionIndex].CorrectAnswerIndex;
            if (isCorrect) _currentScore++;
            return isCorrect;
        }

        public void MoveToNextQuestion() => _currentQuestionIndex++;

        public void ResetQuiz()
        {
            _currentQuestionIndex = 0;
            _currentScore = 0;
        }

        public string GetFinalFeedback()
        {
            double percent = (double)_currentScore / _questions.Count * 100;

            if (percent >= 80)
                return "Excellent! You're a cybersecurity expert!";
            if (percent >= 60)
                return "Good job! You know quite a bit about cybersecurity.";
            if (percent >= 40)
                return "Not bad! Consider reviewing some cybersecurity basics.";
            return "Keep learning! Cybersecurity is important for everyone.";
        }
    }
}

