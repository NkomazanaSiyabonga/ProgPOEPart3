﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CyberSecurityChatBot.Models
{
    public class ChatMessage
    {
        public string Message { get; set; }
        public bool IsUserMessage { get; set; }
        public DateTime Timestamp { get; set; } = DateTime.Now;
    }
}
